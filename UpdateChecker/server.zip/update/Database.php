<?php

// Extended database class
// Date: 2007-07-19

class Database extends mysqli
{
  var $Prefix = '';

  function select($Table, $What = '*', $Condition = 1)
  {
    $Query = "SELECT ".$What." FROM `".$this->Prefix.$Table."` WHERE ".$Condition;
    return($this->query($Query));
  }

  function delete($Table, $Condition)
  {
    $this->query("DELETE FROM `".$this->Prefix.$Table."` WHERE ".$Condition);
  }

  function insert($Table, $Data)
  {
    $Name = '';
    $Values = '';
    foreach($Data as $Key => $Value)
    {
      $Value = strtr($Value, '"', '\"');
      $Name .= ','.$Key;
            if($Value == 'NOW()') $Values .= ",".$Value;
              else $Values .= ",'".$Value."'";
    }
    $Name = substr($Name, 1);
    $Values = substr($Values, 1);
    $this->query('INSERT INTO `'.$this->Prefix.$Table.'` ('.$Name.') VALUES('.$Values.')');
    //echo('INSERT INTO `'.$this->Prefix.$Table.'` ('.$Name.') VALUES('.$Values.')');
  }
  
  function update($Table, $Condition, $Data)
  {
    $Values = '';
    foreach($Data as $Key => $Value)
    {
            $Value = strtr($Value, '"', '\"');
      if($Value != 'NOW()') $Value = "'".$Value."'";
      $Values .= ", ".$Key."=".$Value;
    }
    $Values = substr($Values, 2);
    $this->query('UPDATE `'.$this->Prefix.$Table.'` SET '.$Values.' WHERE ('.$Condition.')');
  }

  function replace($Table, $Data)
  {
    $Name = '';
    $Values = '';
    foreach($Data as $Key => $Value)
    {
      $Value = strtr($Value, '"', '\"');
      $Name .= ",".$Key;
      if($Value == 'NOW()') $Values .= ",".$Value;
        else $Values .= ',"'.$Value.'"';
    }
    $Name = substr($Name, 1);
    $Values = substr($Values, 1);
    $this->query('REPLACE INTO `'.$this->Prefix.$Table.'` (`'.$Name.'`) VALUES('.$Values.')');
    //echo('REPLACE INTO `'.$this->Prefix.$Table.'` (`'.$Name.'`) VALUES('.$Values.')');
  }

  function charset($Charset)
  {
    $this->query('SET NAMES "'.$Charset.'"');
  }
}
