<?php

Header('Content-Type: text/xml'); 

include('Database.php');
include('Config.php');

$Properties = array(
  array('Name' => 'Id', 'Table' => '`Version`.`Id`', 'Type' => 'Integer'),
  array('Name' => 'Application', 'Table' => '`Application`.`Name`', 'Type' => 'String'),
  array('Name' => 'Group', 'Table' => '`Group`.`Name`', 'Type' => 'String'),
  array('Name' => 'Branch', 'Table' => '`Branch`.`Name`', 'Type' => 'String'), 
  array('Name' => 'BranchId', 'Table' => '`Branch`.`Id`', 'Type' => 'Integer'), 
  array('Name' => 'Version', 'Table' => '`Version`.`Version`', 'Type' => 'String'),
  array('Name' => 'Platform', 'Table' => '`Platform`.`Name`', 'Type' => 'Platform'),
  array('Name' => 'Architecture', 'Table' => '`Architecture`.`Name`', 'Type' => 'Architecture'),
  array('Name' => 'ExecutableFile', 'Table' => '`Application`.`ExecutableFile`', 'Type' => 'String'),
  array('Name' => 'SourceURL', 'Table' => '`Version`.`SourceURL`', 'Type' => 'String'),
  array('Name' => 'ReleaseTime', 'Table' => '`Version`.`ReleaseTime`', 'Type' => 'DateTime'),
  array('Name' => 'ReleaseNotes', 'Table' => '`Version`.`ReleaseNotes`', 'Type' => 'String'),
);

$Columns = array();
foreach($Properties as $Property)
{
  $Columns[] = $Property['Table'].' AS `'.$Property['Name'].'Name`';
}
if(count($Columns) > 0) $Columns = implode(', ', $Columns);
  else $Columns = '';

$Query = 'SELECT '.$Columns.' FROM `Version` '.
  'LEFT JOIN `Branch` ON `Branch`.`Id` = `Version`.`Branch` '.
  'LEFT JOIN `Application` ON `Application`.`Id` = `Branch`.`Application` '.
  'LEFT JOIN `Platform` ON `Platform`.`Id` = `Branch`.`Platform` '.
  'LEFT JOIN `Group` ON `Group`.`Id` = `Application`.`Group` '.
  'LEFT JOIN `Architecture` ON `Architecture`.`Id` = `Branch`.`Architecture`';
$Where = array();
foreach($Properties as $Property)
{
  if(array_key_exists($Property['Name'], $_GET)) 
  {  
    if($_GET[$Property['Name']] != '') 
      $Where[] = '('.$Property['Table'].' = "'.mysql_escape_string($_GET[$Property['Name']]).'")';
  }
}
if(count($Where) > 0) $Query .= ' WHERE '.implode(' AND ', $Where);
$Query .= ' ORDER BY `ReleaseTime` DESC';

if(array_key_exists('Limit', $_GET)) 
{
  $Limit = $_GET['Limit'] * 1;
  if($Limit < 0) $Limit = 0;
  $Query .= ' LIMIT 0, '.$Limit;
}

//echo($Query);
$Database = new Database($DbHost, $DbUser, $DbPassword, $DbSchema);
$Database->charset($DbEncoding);
$DbResult = $Database->query($Query);
  
$Output = array();
$Output[] = '<?xml version="1.0"?>';
$Output[] = '<SourceList>';
$Output[] = '<Items>';
while($Row = $DbResult->fetch_assoc())
{
  $Output[] = '<Source>';
  foreach($Properties as $Property)
  {
    if(array_key_exists($Property['Name'], $_GET) and ($_GET[$Property['Name']] == ''))
    {
	  if($Property['Type'] == 'DateTime') $Value = date('c', strtotime($Row[$Property['Name'].'Name']));
	  else if($Property['Type'] == 'String') $Value = htmlspecialchars($Row[$Property['Name'].'Name']);
	  else if($Property['Type'] == 'Integer') $Value = $Row[$Property['Name'].'Name'] * 1;
	  else $Value = '';

  	  $Output[] = '<'.$Property['Name'].'>'.$Value.'</'.$Property['Name'].'>';
  	}
  }
  $Output[] = '</Source>';
}
$Output[] = '</Items>';
$Output[] = '</SourceList>';

echo(implode("\r\n", $Output));

?>
