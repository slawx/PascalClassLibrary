SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Databáze: `d6231_update`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `Application`
--

CREATE TABLE IF NOT EXISTS `Application` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `ShortName` varchar(255) NOT NULL,
  `Website` varchar(255) NOT NULL,
  `Group` int(11) DEFAULT NULL,
  `ExecutableFile` varchar(255) NOT NULL,
  `License` varchar(255) NOT NULL,
  `Author` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Group` (`Group`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Struktura tabulky `Architecture`
--

CREATE TABLE IF NOT EXISTS `Architecture` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `BitWidth` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Struktura tabulky `Branch`
--

CREATE TABLE IF NOT EXISTS `Branch` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `Architecture` int(11) NOT NULL,
  `Platform` int(11) NOT NULL,
  `Application` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Architecture` (`Architecture`),
  KEY `Application` (`Application`),
  KEY `Platform` (`Platform`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Struktura tabulky `Group`
--

CREATE TABLE IF NOT EXISTS `Group` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktura tabulky `Platform`
--

CREATE TABLE IF NOT EXISTS `Platform` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `Vendor` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Struktura tabulky `Version`
--

CREATE TABLE IF NOT EXISTS `Version` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Branch` int(11) NOT NULL,
  `Version` varchar(255) NOT NULL,
  `SourceURL` varchar(255) NOT NULL,
  `ReleaseNotes` text NOT NULL,
  `ReleaseTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Branch` (`Branch`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=52 ;

--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `Branch`
--
ALTER TABLE `Branch`
  ADD CONSTRAINT `Branch_ibfk_3` FOREIGN KEY (`Application`) REFERENCES `Application` (`Id`),
  ADD CONSTRAINT `Branch_ibfk_1` FOREIGN KEY (`Architecture`) REFERENCES `Architecture` (`Id`),
  ADD CONSTRAINT `Branch_ibfk_2` FOREIGN KEY (`Platform`) REFERENCES `Platform` (`Id`);

--
-- Omezení pro tabulku `Version`
--
ALTER TABLE `Version`
  ADD CONSTRAINT `Version_ibfk_1` FOREIGN KEY (`Branch`) REFERENCES `Branch` (`Id`);

