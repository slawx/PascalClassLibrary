<?php

$DbHost = 'localhost';
$DbUser = 'root';
$DbPassword = '';
$DbSchema = 'update';
$DbEncoding = 'utf8';

?>
