Template generics
=================

Tutorial and basic information:
  http://wiki.freepascal.org/Templates

Version: 0.3
Release date: 2011-01-01
Author: Chronos
Email: robie@centrum.cz


Main subversion repository:
http://svn.zdechov.net/svn/PascalClassLibrary/Generics/TemplateGenerics
